#!/usr/bin/python  

import os, sys
import subprocess
import json
import uproot3
import awkward as ak
import numpy as np
from coffea import processor, util, hist
import pickle

with open('lumi.json') as f:
    lumis = json.load(f)

ddbthr = 0.87
ddcthr = 0.02

# Main method
def main():

    raw = False

    if len(sys.argv) < 2:
        print("Enter year")
        return
    elif len(sys.argv) == 3:
        if int(sys.argv[2]) > 0:
            raw = True
    elif len(sys.argv) > 3:
        print("Incorrect number of arguments")
        return

    year = sys.argv[1]

    if os.path.isfile(year+'/1mvl-signalregion.root'):
        os.remove(year+'/1mvl-signalregion.root')
    fout = uproot3.create(year+'/1mvl-signalregion.root')

    samples = ['data','muondata','EWKW', 'EWKZ', 'Wjets', 'Zjets', 'QCD','ttbar','singlet','VV','ggF','VBF','WH','ZH','ttH']

    print("1 V MASS BINS, LIGHT CAT")
    # bins = [40,201]

    # Check if pickle exists     
    picklename = year+'/templates.pkl'
    if not os.path.isfile(picklename):
        print("You need to create the pickle")
        return

    # Read the histogram from the pickle file
    sig = pickle.load(open(picklename,'rb')).integrate('region','signal').integrate('ddc2',int_range=slice(0,ddcthr))#.sum('genflavor2', overflow='all')


    for p in samples:
        print(p)

        hpass = sig.sum('j2pt', overflow ='all').integrate('ddb1',int_range=slice(ddbthr,1)).integrate('process',p)
        hfail = sig.sum('j2pt', overflow ='all').integrate('ddb1',int_range=slice(0,ddbthr)).integrate('process',p)

        fout["l_pass_"+p+"_nominal"] = hist.export1d(hpass)
        fout["l_fail_"+p+"_nominal"] = hist.export1d(hfail)

        # for p in ['Wjets','Zjets']:
        #     print(p)

        #     hpass = sig.integrate('msd2',int_range=slice(bins[i],bins[i+1])).integrate('genflavor1',int_range=slice(1,3)).integrate('ddb1',int_range=slice(ddbthr,1)).integrate('process',p)
        #     hfail = sig.integrate('msd2',int_range=slice(bins[i],bins[i+1])).integrate('genflavor1',int_range=slice(1,3)).integrate('ddb1',int_range=slice(0,ddbthr)).integrate('process',p)

        #     hpass_bb = sig.integrate('msd2',int_range=slice(bins[i],bins[i+1])).integrate('genflavor1',int_range=slice(3,4)).integrate('ddb1',int_range=slice(ddbthr,1)).integrate('process',p)
        #     hfail_bb = sig.integrate('msd2',int_range=slice(bins[i],bins[i+1])).integrate('genflavor1',int_range=slice(3,4)).integrate('ddb1',int_range=slice(0,ddbthr)).integrate('process',p)

        #     fout["l_pass_mv"+str(i+1)+"_"+p+"_nominal"] = hist.export1d(hpass)
        #     fout["l_fail_mv"+str(i+1)+"_"+p+"_nominal"] = hist.export1d(hfail)

        #     fout["l_pass_mv"+str(i+1)+"_"+p+"bb_nominal"] = hist.export1d(hpass_bb)
        #     fout["l_fail_mv"+str(i+1)+"_"+p+"bb_nominal"] = hist.export1d(hfail_bb)

    return

if __name__ == "__main__":
    main()
